
# Number Guessing Game 🎮

This is a simple Python command-line game where the computer randomly selects a number between 1 and 100, and the user tries to guess it.

## Features
- Random number generation
- Input validation
- Feedback for each guess
- Count of attempts

## How to Run
1. Make sure you have Python installed.
2. Run the script using:
   ```bash
   python guessing_game.py
   ```

Enjoy the game!
